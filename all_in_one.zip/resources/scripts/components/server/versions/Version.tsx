import http from '@/api/http';
import Button from '@/components/elements/Button';
import { ServerContext } from '@/state/server';
import React, { useEffect, useState } from 'react';
import tw from 'twin.macro';

interface Props {
    data: any;
    currentVersion: string;
}

export default ({ data, currentVersion }: Props) => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);

    const state = ServerContext.useStoreState((state) => state.status.value);

    const instance = ServerContext.useStoreState((state) => state.socket.instance);

    const [installed, setInstalled] = useState(false);

    async function install() {
        if (state !== 'offline') {
            instance && instance.send('set state', 'control.stop');
        }

        if (installed) {
            http.put(`/api/client/servers/${uuid}/startup/variable`, {
                key: 'SERVER_JARFILE',
                value: 'server.jar',
            });
            http.post(`/api/client/servers/${uuid}/files/delete`, {
                root: '/',
                files: [data.filename],
            });
            setInstalled(false);

            return;
        }

        await http.post(`/api/client/servers/${uuid}/files/pull`, {
            url: `https://proxy.fyrehost.net/?https://mcutils.com/api/server-jars/${data.type}/${data.version}/download`,
            filename: data.filename,
        });

        await http.put(`/api/client/servers/${uuid}/startup/variable`, {
            key: 'SERVER_JARFILE',
            value: data.filename,
        });

        setInstalled(true);
    }

    async function checkInstalled() {
        if (currentVersion === data.filename) {
            setInstalled(true);
        }
    }

    useEffect(() => {
        console.log(JSON.stringify(data))

        checkInstalled();
    }, []);

    return (
        <div
            css={tw`rounded-lg px-4 m-4 py-5 text-center ring ring-neutral-800`}
            style={{ backgroundColor: '#3f4d5a' }}
        >
            {`${data.type} ${data.version}`}
            <button
                css={
                    installed
                        ? tw`text-lg bg-red-700 hover:bg-red-800 text-white rounded-lg p-1 mx-auto w-full border-2 border-red-500`
                        : tw`text-lg bg-green-500 hover:bg-green-400 text-white rounded-lg p-1 mx-auto w-full border-2 border-green-600`
                }
                onClick={install}
            >
                {installed ? 'Uninstall' : state === 'offline' ? 'Install' : 'Stop Server'}
            </button>
        </div>
    );
};
