import http from '@/api/http';
import Spinner from '@/components/elements/Spinner';
import { ServerContext } from '@/state/server';
import React, { ChangeEvent, useEffect, useState } from 'react';

import tw from 'twin.macro';
import CategoryConainer from './CategoryConainer';

const banners = {
    mohist: '/assets/banners/mohist.png',
    fabric: '/assets/banners/fabric.png',
    forge: '/assets/banners/forge.svg',
    catserver: '/assets/banners/catserver.png',
    waterfall: '/assets/banners/waterfall.png',
    bungeecord: '/assets/banners/bungeecord.png',
    velocity: '/assets/banners/velocity.png',
    vanilla: '/assets/banners/vanilla.png',
    snapshot: '/assets/banners/snapshots.png',
    paper: '/assets/banners/paper.svg',
    purpur: '/assets/banners/purpur.svg',
    sponge: '/assets/banners/spong.svg',
    folia: '/assets/banners/folia.png',
    craftbukkit: '/assets/banners/bukkit.png',
    spigot: '/assets/banners/spigot.png'
};

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);

    const temp: JSX.Element[] = [];

    const [serverCategories, setServerCategories] = useState(temp);

    const [searchStr, setSearch] = useState('');

    const [loading, setLoading] = useState(true);

    async function load() {
        setLoading(true);

        const req = await fetch('https://proxy.fyrehost.net/?https://mcutils.com/api/server-jars');

        const res = await req.json();

        console.log(res);

        const types = [];

        for (let index = 0; index < res.length; index++) {
            const element = res[index];
            types.push(element.key);
        }

        const temp: JSX.Element[] = [];

        let currentVersion = '';

        const version = await http.get(`/api/client/servers/${uuid}/startup`);

        for (let i = 0; i < version.data.data.length; i++) {
            if (version.data.data[i].attributes.name === 'Server Jar File') {
                currentVersion = version.data.data[i].attributes.server_value;
            }
        }

        for (let i = 0; i < types.length; i++) {
            temp.push(
                <CategoryConainer
                    currentVersion={currentVersion}
                    search={searchStr}
                    category={types[i]}
                    image={banners[types[i] as keyof typeof banners]}
                    key={Math.random()}
                ></CategoryConainer>
            );
        }

        setServerCategories(temp);

        setLoading(false);
    }

    function onSearch(event: ChangeEvent<HTMLInputElement>) {
        setSearch(event.target.value);
    }

    useEffect(() => {
        setLoading(true);
        load();
    }, [searchStr]);

    return (
        <>
            <div css={tw`px-4 mt-4`}>
                <input
                    onChange={onSearch}
                    css={tw`rounded-lg bg-neutral-700 border-2 border-cyan-700 text-lg p-2 w-full`}
                    style={{ backgroundColor: '#3f4d5a', borderColor: '#6b7280' }}
                    placeholder={'search'}
                />
            </div>

            {loading ? (
                <Spinner size='large' css={tw`mx-auto`}></Spinner>
            ) : (
                <>
                    <div css={tw`flex flex-wrap overflow-hidden`}>{serverCategories}</div>
                </>
            )}
        </>
    );
};
