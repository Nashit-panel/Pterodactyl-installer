import Button from '@/components/elements/Button';
import React, { useEffect, useState } from 'react';

import tw from 'twin.macro';
import Version from './Version';

interface Props {
    category: any;
    search: string;
    currentVersion: string;
    image: string;
}

export default ({ category, search, currentVersion, image }: Props) => {
    const temp: JSX.Element[] = [];

    const [loading, setLoading] = useState(true);

    const [versions, setVersions] = useState(temp);

    async function load() {
        const req = await fetch(`https://proxy.fyrehost.net/?https://mcutils.com/api/server-jars/${category}`);

        const res = await req.json();

        console.log(res);

        const v = [];

        for (let i = 0; i < res.length; i++) {
            v.push({
                version: res[i].version,
                type: category,
                filename: `${category}-${res[i].version}.jar`,
            });
        }

        const vr: JSX.Element[] = [];

        for (let i = 0; i < v.length; i++) {
            if (v[i].filename.includes(search)) {
                vr.push(<Version currentVersion={currentVersion} data={v[i]} key={Math.random()}></Version>);
            }
        }

        setVersions(vr);
    }

    useEffect(() => {
        setLoading(true);
        load();
    }, []);

    return (
        <>
            <div css={tw`w-1/2 p-4`}>
                <div css={tw`rounded-lg border-0`} style={{ backgroundColor: '#3f4d5a', borderColor: '#6b7280' }}>
                    <Button
                        css={tw`w-full border-0 rounded-lg h-40`}
                        style={{ backgroundColor: '#3f4d5a' }}
                        onClick={() => {
                            setLoading(!loading);
                        }}
                    >
                        <img css={tw`max-h-full max-w-full mx-auto`} src={image}></img>
                        {/*
                        <p css={tw`text-2xl`}>{type}</p>
                        */}
                    </Button>
                    <div css={!loading ? tw`pb-2` : tw``}>{!loading && versions}</div>
                </div>
            </div>
        </>
    );
};
